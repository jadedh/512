﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class private_Show : System.Web.UI.Page
{
    private static int commentNum = 1;
    private const string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection connection = new SqlConnection(connString);
        connection.Open();
        SqlCommand command = new SqlCommand("SELECT Comment FROM Comments WHERE Id = '" + commentNum.ToString() +"'" , connection);
        command.ExecuteNonQuery();
        String yourValue = (String)command.ExecuteScalar();
        if (yourValue == null)
        {
            TextBox1.Text = "No more comments.";
        }
        else
        {
            TextBox1.Text = yourValue;
        }
        connection.Close();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        commentNum++;
        SqlConnection connection = new SqlConnection(connString);
        connection.Open();
        SqlCommand command = new SqlCommand("SELECT Comment FROM Comments WHERE Id = '" + commentNum.ToString() + "'", connection);
        //command.ExecuteNonQuery();
        String yourValue = (String)command.ExecuteScalar();
        if(yourValue == null)
        {
            commentNum--;
            TextBox1.Text = "No more comments.";
        }
        else
        {
            TextBox1.Text = yourValue;
        }
        
        connection.Close();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection connection = new SqlConnection(connString);
        connection.Open();
        SqlCommand command = new SqlCommand("drop table Comments"/*"delete from Comments"*/, connection);
        command.ExecuteNonQuery();
        SqlCommand command2 = new SqlCommand("CREATE TABLE[dbo].[Comments]([Id] INT IDENTITY(1, 1) NOT NULL,[comment] NVARCHAR(MAX) NULL)", connection);
        command2.ExecuteNonQuery();
        connection.Close();
        TextBox1.Text = "Deleted All Comments";
        commentNum = 1;
    }
}