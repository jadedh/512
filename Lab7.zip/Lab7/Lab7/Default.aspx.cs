﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    private const string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if(TextBox1.Text == "" || TextBox1.Text =="Please enter a comment.")
        {
            TextBox1.Text = "Please enter a comment.";
        }
        else
        {
            SqlConnection connection = new SqlConnection(connString);
            String query = "INSERT INTO Comments (Comment) VALUES (@Comment)";
            connection.Open();
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Comment", TextBox1.Text);
                int result = command.ExecuteNonQuery();
                TextBox1.Text = "Thank you for your comment";
            }
            connection.Close();
        
        }
        
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("/private/Show.aspx");
    }
}