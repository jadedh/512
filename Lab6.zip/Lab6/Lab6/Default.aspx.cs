﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    private const string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Survey.mdf;Integrated Security=True";

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        using (SqlConnection connection = new SqlConnection(connString))
        {
            String query = "DELETE FROM Foods WHERE Id = '" + DropDownList1.Text + "'";
            connection.Open();
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                int result = command.ExecuteNonQuery();
                // Check Error
                //if (result < 0)
                //    Console.WriteLine("Error inserting data into Database!");

                Label1.Text = "Deleted Food";
            }
            connection.Close();
        }

        DropDownList1.DataBind();
        CheckBoxList1.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            Label1.Text = "missing unit";
        }
        else
        {

            using (SqlConnection connection = new SqlConnection(connString))
            {
                String query = "INSERT INTO Foods (Food,Count) VALUES (@Food,@Count)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Food", TextBox1.Text);
                    command.Parameters.AddWithValue("@Count", 0);

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    Label1.Text = "Added Food";
                    connection.Close();
                    DropDownList1.DataBind();
                    CheckBoxList1.DataBind();
                }
            }
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < CheckBoxList1.Items.Count; i++)
        {
            if (CheckBoxList1.Items[i].Selected)
            {
                string str = CheckBoxList1.Items[i].Text;
                Response.Write("<p>" + str + "</p>");

                string itemValue = CheckBoxList1.Items[i].Value;
                Response.Write("<p>" + itemValue + "</p>");

                Update(itemValue);
            }
        }
        Response.Redirect("Report.aspx");
    }
    private void Update(string id)
    {
        using (SqlConnection connection = new SqlConnection(connString))
        {
            using (SqlCommand cmd = new SqlCommand("Update Foods SET Count=Count + 1 WHERE Id='" + id + "'", connection))
            {
                connection.Open();
                cmd.ExecuteNonQuery();
                connection.Close();
            }
        }
        
    }

    protected void HiddenField1_ValueChanged(object sender, EventArgs e)
    {

    }
}