﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Lab3calc : System.Web.UI.Page
{

    static double currentVal = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void enter_Click(object sender, EventArgs e)
    {

        try
        {
            currentVal = Convert.ToDouble(input.Text);
            result.Text = currentVal.ToString();
            error.Text = "";
            input.Text = "";


        }
        catch
        {
            error.Text = "Invalid or missing value!";
        }

    }

    protected void add_Click(object sender, EventArgs e)
    {
        try
        {
            currentVal = currentVal + Convert.ToDouble(input.Text);
            result.Text = currentVal.ToString();
            error.Text = "";
            input.Text = "";
        }
        catch
        {
            error.Text = "Invalid or missing values!";
        }
    }

    protected void sub_Click(object sender, EventArgs e)
    {
        try
        {
            currentVal = currentVal - Convert.ToDouble(input.Text) ;
            result.Text = currentVal.ToString();
            error.Text = "";
            input.Text = "";
        }
        catch
        {
            error.Text = "Invalid or missing values!";
        }
    }

    protected void mul_Click(object sender, EventArgs e)
    {
        try
        {
            currentVal = currentVal * Convert.ToDouble(input.Text);
            result.Text = currentVal.ToString();
            error.Text = "";
            input.Text = "";
        }
        catch
        {
            error.Text = "Invalid or missing values!";
        }
    }

    protected void div_Click(object sender, EventArgs e)
    {
        try
        {
            currentVal = currentVal / Convert.ToDouble(input.Text);
            result.Text = currentVal.ToString();
            error.Text = "";
            input.Text = "";
        }
        catch
        {
            error.Text = "Invalid or missing values!";
        }
    }
}

