﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Modify : System.Web.UI.Page
{
    private const string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Lab4DB.mdf;Integrated Security=True";

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        double test;
        if (TextBox1.Text == "")
        {
            Label4.Text = "missing unit";
        }
        else if (TextBox2.Text == "")
        {
            Label4.Text = "missing factor";
        }
        else if (!double.TryParse(TextBox2.Text, out test))
        {
            Label4.Text = "Not a number";
        }
        else
        {
            
            using (SqlConnection connection = new SqlConnection(connString))
            {
                String query = "INSERT INTO Conversions (Unit,Factor) VALUES (@Unit,@Factor)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Unit", TextBox1.Text);
                    command.Parameters.AddWithValue("@Factor", TextBox2.Text);

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    // Check Error
                    //if (result < 0)
                    //    Console.WriteLine("Error inserting data into Database!");
                    
                    Label4.Text = "Added Unit";
                    connection.Close();
                    DropDownList1.DataBind();
                }
            }
        }


    }


    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        using (SqlConnection connection = new SqlConnection(connString))
        {
            String query = "DELETE FROM Conversions WHERE Id = '" + DropDownList1.Text + "'";
            connection.Open();
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                int result = command.ExecuteNonQuery();
                // Check Error
                //if (result < 0)
                //    Console.WriteLine("Error inserting data into Database!");
                
                Label4.Text = "Deleted Unit" ;
            }
            connection.Close();
        }

        DropDownList1.DataBind();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}