﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Lab4 : System.Web.UI.Page
{
    private const string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Lab4DB.mdf;Integrated Security=True";
    
    protected void Page_Load(object sender, EventArgs e)
    {


    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    //

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(connString);
        string drop1 = DropDownList1.SelectedItem.Text;
        string drop2 = DropDownList2.SelectedItem.Text;
        string sqlstrFrom = String.Format("SELECT Factor FROM Conversions Where (Unit = '{0}')", drop1);
        string sqlstrTo = String.Format("SELECT Factor FROM Conversions Where (Unit = '{0}')", drop2);
        //Response.Write("<br />" + sqlstr);


        double Num;
        bool isNum = double.TryParse(TextBox1.Text, out Num);
        if (drop1 == drop2)
        {
            TextBox2.Text = "";
            Label2.Text = "Error: Units are the same.";
        }
        else if (isNum)
        {
            conn.Open();
            SqlCommand cmdFrom = new SqlCommand(sqlstrFrom, conn);
            SqlDataReader rdrFrom = cmdFrom.ExecuteReader();
            rdrFrom.Read();
            double factorFrom = (double)rdrFrom["Factor"];
            conn.Close();

            conn.Open();
            SqlCommand cmdTo = new SqlCommand(sqlstrTo, conn);
            SqlDataReader rdrTo = cmdTo.ExecuteReader();
            rdrTo.Read();
            double factorTo = (double)rdrTo["Factor"];
            conn.Close();


            double output = (Convert.ToDouble(TextBox1.Text) * factorFrom) / factorTo;
            //Response.Write("<br />" + output);
            TextBox2.Text = Convert.ToString(output);
            Label2.Text = "";
            
        }
        else
        {
            TextBox2.Text = "";
            Label2.Text = "Error: Invalid input. Enter numericals";
        }

    }
        

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Modify.aspx");
    }
}